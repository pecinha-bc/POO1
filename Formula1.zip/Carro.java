package avaliacao.formula1;

public class Carro {

    private int numero;
    private int posicao;
    private Equipe equipe;
    private Piloto piloto;

    public Carro(int numero, int posicao, Equipe equipe, Piloto piloto) {
        this.numero = numero;
        this.posicao = posicao;
        this.equipe = equipe;
        this.piloto = piloto;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getPosicao() {
        return posicao;
    }

    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }

    public Equipe getEquipe() {
        return equipe;
    }

    public void setEquipe(Equipe equipe) {
        this.equipe = equipe;
    }

    public Piloto getPiloto() {
        return piloto;
    }

    public void setPiloto(Piloto piloto) {
        this.piloto = piloto;
    }

    public void exibir() {
        System.out.println("=== Carro #" + numero + " ===");
        System.out.println("Posição: " + posicao + "º");
        System.out.println("--- Equipe ---");
        equipe.exibir();
        System.out.println("--- Piloto ---");
        piloto.exibir();
    }
}
