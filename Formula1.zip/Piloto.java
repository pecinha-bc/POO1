package avaliacao.formula1;

public class Piloto extends Pessoa {

    private int numeroDeVitorias;

    public Piloto(String nome, int idade, String nacionalidade, int numeroDeVitorias) {
        super(nome, idade, nacionalidade);
        this.numeroDeVitorias = numeroDeVitorias;
    }

    public int getNumeroDeVitorias() {
        return numeroDeVitorias;
    }

    public void setNumeroDeVitorias(int numeroDeVitorias) {
        this.numeroDeVitorias = numeroDeVitorias;
    }

    @Override
    public void exibir() {
        super.exibir();
        System.out.println("Número de vitórias: " + numeroDeVitorias);
    }
}
