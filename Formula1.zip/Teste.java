package avaliacao.formula1;

public class Teste {

    public static void main(String[] args) {

        // Criando patrocinadores
        Patrocinador pat1 = new Patrocinador("Oracle", 85000000.00);
        Patrocinador pat2 = new Patrocinador("Honda", 120000000.00);
        Patrocinador pat3 = new Patrocinador("Pirelli", 40000000.00);

        Patrocinador pat4 = new Patrocinador("Petronas", 95000000.00);
        Patrocinador pat5 = new Patrocinador("Tommy Hilfiger", 30000000.00);

        // Criando equipes com vetor de patrocinadores
        Equipe redBull = new Equipe("Red Bull Racing", 2005, new Patrocinador[]{pat1, pat2, pat3});
        Equipe mercedes = new Equipe("Mercedes AMG", 2010, new Patrocinador[]{pat4, pat5});

        // Criando pilotos (herdam de Pessoa)
        Piloto verstappen = new Piloto("Max Verstappen", 26, "Holandesa", 62);
        Piloto hamilton = new Piloto("Lewis Hamilton", 39, "Britânica", 103);

        // Criando carros
        Carro carro1 = new Carro(1, 1, redBull, verstappen);
        Carro carro2 = new Carro(44, 2, mercedes, hamilton);

        // Criando engenheiros (herdam de Pessoa)
        Engenheiro eng1 = new Engenheiro("Gianpiero Lambiase", 50, "Italiana", verstappen);
        Engenheiro eng2 = new Engenheiro("Peter Bonnington", 48, "Britânica", hamilton);

        // Exibindo tudo
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║        FÓRMULA 1 - TEMPORADA         ║");
        System.out.println("╚══════════════════════════════════════╝\n");

        carro1.exibir();
        System.out.println();
        carro2.exibir();

        System.out.println("\n====== ENGENHEIROS ======");
        System.out.println("\n--- Engenheiro 1 ---");
        eng1.exibir();
        System.out.println("\n--- Engenheiro 2 ---");
        eng2.exibir();
    }
}
