package avaliacao.formula1;

public class Patrocinador {

    private String nome;
    private double valorDoPatrocinio;

    public Patrocinador(String nome, double valorDoPatrocinio) {
        this.nome = nome;
        this.valorDoPatrocinio = valorDoPatrocinio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValorDoPatrocinio() {
        return valorDoPatrocinio;
    }

    public void setValorDoPatrocinio(double valorDoPatrocinio) {
        this.valorDoPatrocinio = valorDoPatrocinio;
    }

    public void exibir() {
        System.out.println("Patrocinador: " + nome + " | Valor: R$ " + valorDoPatrocinio);
    }
}
